# Serenity Farewells - Funeral Parlor Website

A compassionate and professional website for Serenity Farewells funeral services in South Africa.

## Project Structure
